#ifndef APP_H_
#define APP_H_
#include <STDIO.H>
#include "Derail.h"
#include "DigitalTube.h"
#include "MatrixKey.h"
#include "Time_Interrupt.h"

void Dssplay_Series_Num();

void Display_Regular_Num();

void Button_with_Delay();

void Add_Key_Number();

void Init_Int0();



#endif