#include "app.h"

void main()
{
    Dssplay_Series_Num();
}